import dao.ProdutoDAO;
import model.Produto;
import service.ProdutoService;

public class Test {
    public static void main(String[] args) {
        Produto produto = new Produto();
        ProdutoService ps = new ProdutoService();

        produto.setNome("Celular");
        produto.setCategoria("Eletrônicos");
        produto.setQuantidadeEstoque(12);
        produto.setPreco(18.99);


    }
}
